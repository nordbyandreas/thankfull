




document.getElementById('yellow').onclick = function() {
  document.getElementById('colors').setAttribute('href', 'css/yellow.css');
};



document.getElementById('red').onclick = function() {
  document.getElementById('colors').setAttribute('href', 'css/red.css');
};

document.getElementById('orange').onclick = function() {
  document.getElementById('colors').setAttribute('href', 'css/orange.css');
};
